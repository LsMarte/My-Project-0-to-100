/*
 * Name: Your Name
 * Lottery Project
 * Course: CSI107 (Spring 2024)
 * Date: March 5, 2024
 * Description: Compute the odds of any single
 *				daily number or million-dollar
 *				lottery number coming up. If
 *				odds of winning with 1 number
 *				are above a threshold, generate
 *				a random lottery number.
 */

#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <ctime>
using namespace std;

// Enumeration for type of lottery.
enum LotteryType { DAILY_NUMBERS, MILLION_DOLLAR };


// FUNCTION PROTOTYPES.
int generateRandomInRange(int lower, int upper);

int computeTotalMillionDollarNumbers(int range,
	                                 int numPos);

int main()
{
	// Maximum values (digits or number) in a
	// lottery number.
	const int MAX_POSITIONS = 8;

	// Number of possible digits each position
	// of a daily number.
	const int DIGITS_PER_POSITION = 10;

	// Minimum odds of winning in order to
	// generate a random lottery number.
	const double ODDS_TO_GENERATE = 1e-7;

	// Letter entered by user for lottery type.
	char lotteryChoice;

	// Type of lottery for which to compute odds
	// and possibly generate lottery number.
	LotteryType lotteryType;

	// Number of values (digits or numbers) in
	// lottery number.
	int numberOfPositions;

	// Range of values for million-dollar lottery.
	int rangeOfValues;

	// Total number of possible lottery numbers
	// for chosen type of lottery.
	int totalLotteryNumbers;

	// Probability of winning via a single lottery
	// number for chosen type of lottery.
	double probabilityLotteryNumber;

	// Odds of winning via a single lottery
	// number for chosen type of lottery.
	double oddsLotteryNumber;

	// Display floating-pts values using
	// scientific notation with setprecision()
	// decimal places.
	cout << scientific << setprecision(8);

	// Get type of lottery via a letter choice.
	// Validate that user enters valid letter
	// (if not, repeat). 
	bool validType;
	do
	{
		cout << "Enter type of lottery (d = daily numbers, m = million dollar): ";
		cin >> lotteryChoice;

		if (lotteryChoice == 'd' || lotteryChoice == 'D')
		{
			lotteryType = DAILY_NUMBERS;
			validType = true;
		}
		else if (lotteryChoice == 'm' || lotteryChoice == 'M')
		{
			lotteryType = MILLION_DOLLAR;
			validType = true;
		}
		else
		{
			cerr << "Lottery type can be only 'd' or 'm'" << endl;
			validType = false;
		}
	} while (!validType);

	// Get number of positions in lottery number.
	do
	{
		cout << "Enter number of positions in lottery number (between 1 and "
			 << MAX_POSITIONS << "): ";
		cin >> numberOfPositions;
	} while (numberOfPositions < 1 || numberOfPositions > MAX_POSITIONS);

	// Compute total lottery numbers differently
	// based on type of lottery.

	if (lotteryType == DAILY_NUMBERS)
	{
		// Compute total lottery numbers for a daily
		// numbers with specified number of digits.
		totalLotteryNumbers = static_cast<int>(pow(DIGITS_PER_POSITION, numberOfPositions));
	}
	else
	{
		// Allow user to enter number of values from
		// which million-dollar lottery numbers are
		// chosen.

		do {
			cout << "Enter range of values in lottery number "
				<< "(ex: N in 1...N, at least "
				<< numberOfPositions << "): ";
			cin >> rangeOfValues;
		} while (rangeOfValues < numberOfPositions);

		totalLotteryNumbers =
			computeTotalMillionDollarNumbers(
				rangeOfValues, numberOfPositions);
	}

	// Compute probability of single lottery number.
	// Probability is number of occurrences of event
	// of interest out of total number of possible events
	// (if all events are equiprobable).
	probabilityLotteryNumber = 1.0 / totalLotteryNumbers;

	// Compute odds of a single lottery number (favorable
	// event) out of all other lottery numbers (unfavorable
	// events) [here, written in terms of probability].
	// See: https://towardsdatascience.com/odds-probability-c9cf80405027
	oddsLotteryNumber =
		probabilityLotteryNumber / (1.0 - probabilityLotteryNumber);

	// Display odds of single lottery number for
	// chosen type of lottery.
	cout << "Odds of lottery number: "
		 << oddsLotteryNumber << endl;

	// Test whether odds are sufficient to warrant
	// generating a lottery number.
	if (oddsLotteryNumber >= ODDS_TO_GENERATE)
	{
		// Seed random numbers to get a different
		// sequence each "time" run.
		srand(static_cast<unsigned int>(time(NULL)));

		// Display random lottery number.

		cout << "Lottery number:";

		// CANNOT ACCESS VARIABLE BEFORE DECLARED.
		//cout << rangeLower;
		
		int rangeLower;
		int rangeUpper;

		switch (lotteryType)
		{
		case DAILY_NUMBERS:
			rangeLower = 0;
			rangeUpper = DIGITS_PER_POSITION - 1;
			break;
		case MILLION_DOLLAR:
			rangeLower = 1;
			rangeUpper = rangeOfValues;
			break;
		}

		// Display random value (digit or number)
		// for each position in lottery number.
		for (int posNum = 1; posNum <= numberOfPositions; posNum++)
			cout << ' '
			     << generateRandomInRange(rangeLower, rangeUpper);
		cout << endl;
		// SCOPE OF VAR INIT IN for LOOP IS LOOP.
		//cout << posNum;
	}

	// CANNOT ACCESS BLOCK VAR AFTER BLOCK.
	//cout << rangeUpper;

	return 0;
}

// FUNCTION DEFINITIONS.
int generateRandomInRange(int lower, int upper)
{
	// CANNOT ACCESS LOCAL VAR FROM ANOTHER SCOPE.
	//cout << numberOfPositions;
	int rangeSize = upper - lower + 1;
	return rand() % rangeSize + lower;
}

int computeTotalMillionDollarNumbers(int range,
	                                 int numPos)
{
	// Compute total lottery numbers for million-
	// dollar lottery. Initialize to number of choices
	// for 1st value.
	int numValsChosen = 1;
	int totalNums = range;

	// Compute total lottery numbers by considering
	// 2+ additional values in lottery number.
	while (numValsChosen < numPos)
	{
		// Compute increase in number of lottery
		// numbers due to additional value.
		totalNums *=
			range - numValsChosen;

		// Record that chose an additional value.
		numValsChosen++;

		// Do not count duplicate lottery numbers
		// (same values but in different order).
		totalNums /= numValsChosen;
	}

	return totalNums;
}