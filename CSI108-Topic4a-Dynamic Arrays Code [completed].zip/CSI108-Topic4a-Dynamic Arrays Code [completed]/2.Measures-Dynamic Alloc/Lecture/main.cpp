/*
 * Name: YOUR NAME
 * Measures Project
 * Course: CSI108 (Fall 2024)
 * Date: October 21, 2024
 * Description: Using dynamic allocation.
 */

#include <iostream>
#include <string>
#include <cctype>
#include <new>  // for nothrow version of new operator
using namespace std;

enum MeasureUnits { UNITS_CUPS, UNITS_FLUID_OUNCES };

// IngredMeasure class definition.
class IngredMeasure
{
public:
	// Constants
	static const double OUNCES_IN_CUP;

	IngredMeasure(double initAmt, MeasureUnits initUnits);
	IngredMeasure();

	double getAmt() const;
	MeasureUnits getUnits() const;
	void output() const;
	void convertToUnits(MeasureUnits newUnits);
	void set(double newAmt, MeasureUnits newUnits);
	void input();

private:
	double amt;
	MeasureUnits units;
};

// Ingredient class definition.
class Ingredient
{
public:
	Ingredient(const IngredMeasure& measure,
			   const string& initName);
	Ingredient();

	void output() const;
	void setName(const string& newName);
	void input();

private:
	IngredMeasure measurement;
	string name;
};

int main()
{
	// Output floating-point numbers to one decimal place.
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(1);

	// Recipe contains a list of ingredients.
	// CHANGE TO DYNAMICALLY-ALLOCATED ARRAY.
	//const int NUM_INGREDS = 2;
	//Ingredient ingreds[NUM_INGREDS];

	// GET NUMBER OF INGREDIENTS FROM USER.
	cout << "Enter # of ingredients: ";
	int numIngreds;
	cin >> numIngreds;

	// DECLARE POINTER AND DYNAMICALLY-ALLOCATE ARRAY.
	Ingredient* ingreds = new (nothrow) Ingredient[numIngreds];

	// TEST FOR SUCCESSFUL ALLOCATION.
	if (ingreds == NULL)
	{
		cerr << "Not enough space for ingredients" << endl;
	}
	else
	{
		cout << "\nEnter " << numIngreds
			<< " ingredients(one per line, ex: 1 cups milk) :" << endl;
		for (int i = 0; i < numIngreds; i++)
			ingreds[i].input();

		cout << "\nRecipe ingredients:" << endl;
		for (int i = 0; i < numIngreds; i++)
		{
			ingreds[i].output();
			cout << endl;
		}

		// DEALLOCATE ARRAY, THEN RESET POINTER AND
		// RELATED VARIABLES (SUCH AS # OF INGREDIENTS).
		delete[] ingreds;	// prevent memory leak
		ingreds = NULL;		// avoid dangling pointer
		numIngreds = 0;		// reset related variable(s)
	}

	return 0;
}

// IngredMeasure static member definitions.

const double IngredMeasure::OUNCES_IN_CUP = 8.0;

// IngredMeasure member function definitions.

IngredMeasure::IngredMeasure(double initAmt, MeasureUnits initUnits)
: amt(initAmt), units(initUnits)
{
}

IngredMeasure::IngredMeasure()
: amt(0.0), units(UNITS_CUPS)
{
}

double IngredMeasure::getAmt() const
{
	return amt;
}

MeasureUnits IngredMeasure::getUnits() const
{
	return units;
}

void IngredMeasure::output() const
{
	cout << amt << ' ';

	if (units == UNITS_CUPS)
		cout << "cups";
	else if (units == UNITS_FLUID_OUNCES)
		cout << "ounces";
}

void IngredMeasure::convertToUnits(MeasureUnits newUnits)
{
	if (units == UNITS_FLUID_OUNCES && newUnits == UNITS_CUPS)
		amt /= OUNCES_IN_CUP;
	else if (units == UNITS_CUPS && newUnits == UNITS_FLUID_OUNCES)
		amt *= OUNCES_IN_CUP;

	units = newUnits;
}

void IngredMeasure::set(double newAmt, MeasureUnits newUnits)
{
	amt = newAmt;
	units = newUnits;
}

void IngredMeasure::input()
{
	string unitsName;

	cin >> amt >> unitsName;

	if (unitsName == "cups")
		units = UNITS_CUPS;
	else if (unitsName == "ounces")
		units = UNITS_FLUID_OUNCES;
	else
		cerr << "Unknown units \"" << unitsName << "\"" << endl;
}

// Ingredient member function definitions.

Ingredient::Ingredient(
			const IngredMeasure& initMeasure,
			const string& initName)
	: measurement(initMeasure.getAmt(), initMeasure.getUnits()),
	  name(initName)
{
}

Ingredient::Ingredient()
	: measurement(), name("")
{
}

void Ingredient::output() const
{
	measurement.output();
	cout << '\t' << name;
}

void Ingredient::setName(const string& newName)
{
	name = newName;
}

void Ingredient::input()
{
	measurement.input();
	cin >> ws;  // skip whitespace using "ws" manipulator
	getline(cin, name);
}
