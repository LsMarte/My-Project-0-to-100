/*
 * Name: Your Name
 * Lottery Project
 * Course: CSI107 (Spring 2024)
 * Date: March 28, 2024
 * Description: Compute the odds of any single
 *				daily number or million-dollar
 *				lottery number coming up. If
 *				odds of winning with 1 number
 *				are above a threshold, generate
 *				a random lottery number. Store
 *				lottery number in array so that
 *				duplicates values can be avoided
 *				for million-dollar lotteries.

#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cassert>
using namespace std;

// Enumeration for type of lottery.
enum LotteryType { DAILY_NUMBERS, MILLION_DOLLAR };

// Number of possible digits each position
// of a daily number.
const int DIGITS_PER_POSITION = 10;

// FUNCTION PROTOTYPES.

// Read the type of lottery number from user, validates
// that it is entered correctly (requires user to re-enter
// if invalid), then returns the validated type.
LotteryType getLotteryType();

// Allow user to enter number of values 'rangeVals'
// from which million-dollar lottery numbers are chosen.
void getRangeOfValues(int numPos, int& rangeVals);
// Postcondition: 'rangeVals' is validated to be at
// least as large as 'numPos', number of positions
// in lottery number.

// Generate a random number in a particular range.
int generateRandomInRange(int lower, int upper);
// Precondition: 'lower' should be <= 'upper'.
// Postcondition: return value always between
// 'lower' and 'upper' (inclusively).

//int computeTotalLotteryNumbers(int numPos);

// Compute number of lottery numbers in which values
// are chosen from 'range' values, used to fill a
// number with 'numPos' positions. If 'replacement',
// then values can be re-used each position.
int computeTotalLotteryNumbers(int range,
	                           int numPos,
	                           bool replacement = false);

// Generate a random lottery number with 'numPos'
// positions. Each value may be a number in range
// from 'lower' to 'upper'.
//void generateAndDisplayLotteryNumber(int numPos, int lower, int upper);

// Returns whether the value 'newValue' already exists in array
// 'values' with 'numValues' filled in. Used to prevent duplicates
// in array.
bool containsDuplicate(const int values[], int numValues, int newValue);
// Precondition: 'values' cannot already contain a duplicate value.

// Generate a random lottery number with 'numPos' values.
// Each value may be a number in range from 'lower' to 'upper'.
// Will not repeat any values if 'allowDuplicates' is true.
void generateLotteryNumber(int lotNum[],
						  int numPos,
					      int lower, int upper,
						  bool allowDuplicates);

// Display a lottery number with 'numPos' values
// separated by spaces.
void displayLotteryNumber(const int lotNum[], int numPos);

int main()
{
	// Maximum values (digits or number) in a
	// lottery number.
	const int MAX_POSITIONS = 8;

	// Minimum odds of winning in order to
	// generate a random lottery number.
	const double ODDS_TO_GENERATE = 1e-7;

	// Type of lottery for which to compute odds
	// and possibly generate lottery number.
	LotteryType lotteryType;

	// Number of values (digits or numbers) in
	// lottery number.
	int numberOfPositions;

	// Range of values for million-dollar lottery.
	int rangeOfValues;

	// Total number of possible lottery numbers
	// for chosen type of lottery.
	int totalLotteryNumbers;

	// Probability of winning via a single lottery
	// number for chosen type of lottery.
	double probabilityLotteryNumber;

	// Odds of winning via a single lottery
	// number for chosen type of lottery.
	double oddsLotteryNumber;

	// Display floating-pts values using
	// scientific notation with setprecision()
	// decimal places.
	cout << scientific << setprecision(8);

	// Acquire the type of lottery from user.
	lotteryType = getLotteryType();

	// Get number of positions in lottery number.
	do
	{
		cout << "Enter number of positions in lottery number (between 1 and "
			 << MAX_POSITIONS << "): ";
		cin >> numberOfPositions;
	} while (numberOfPositions < 1 || numberOfPositions > MAX_POSITIONS);

	// Compute total lottery numbers differently
	// based on type of lottery.

	// Determine range of value (digit or number)
	// for generating random lottery numbers. Also
	// whether values can be repeated.
	int rangeLower;
	int rangeUpper;
	bool allowRepeats;

	switch (lotteryType)
	{
	case DAILY_NUMBERS:
		rangeLower = 0;
		rangeUpper = DIGITS_PER_POSITION - 1;
		rangeOfValues = DIGITS_PER_POSITION;
		allowRepeats = true;
		break;

	case MILLION_DOLLAR:
		rangeLower = 1;
		getRangeOfValues(numberOfPositions, rangeOfValues);
		rangeUpper = rangeOfValues;
		allowRepeats = false;
		break;
	}

	// Compute total lottery numbers for a type of lottery
	// given range of values and whether can repeat values.
	totalLotteryNumbers =
		computeTotalLotteryNumbers(
			rangeOfValues,
			numberOfPositions,
			allowRepeats
		);

	// Compute probability of single lottery number.
	// Probability is number of occurrences of event
	// of interest out of total number of possible events
	// (if all events are equiprobable).
	probabilityLotteryNumber = 1.0 / totalLotteryNumbers;

	// Compute odds of a single lottery number (favorable
	// event) out of all other lottery numbers (unfavorable
	// events) [here, written in terms of probability].
	// See: https://towardsdatascience.com/odds-probability-c9cf80405027
	oddsLotteryNumber =
		probabilityLotteryNumber / (1.0 - probabilityLotteryNumber);

	// Ensure odds are not negative.
	assert(oddsLotteryNumber >= 0.0);

	// Display odds of single lottery number for
	// chosen type of lottery.
	cout << "Odds of lottery number: "
		 << oddsLotteryNumber << endl;

	// Test whether odds are sufficient to warrant
	// generating a lottery number.
	if (oddsLotteryNumber >= ODDS_TO_GENERATE)
	{
		// Seed random numbers to get a different
		// sequence each "time" run.
		srand(static_cast<unsigned int>(time(NULL)));

		// Display random lottery number.

		// TRY: REMOVING SIZE, GIVING FEW INITIALIZER THAN
		// SIZE, ...
		int lotteryNumber[MAX_POSITIONS] /*= {
			generateRandomInRange(rangeLower, rangeUpper),
			generateRandomInRange(rangeLower, rangeUpper),
			generateRandomInRange(rangeLower, rangeUpper),
			generateRandomInRange(rangeLower, rangeUpper),
			generateRandomInRange(rangeLower, rangeUpper),
			generateRandomInRange(rangeLower, rangeUpper),
			generateRandomInRange(rangeLower, rangeUpper),
			generateRandomInRange(rangeLower, rangeUpper),
		}*/;

		cout << "Lottery number:";

		// Generate random values for position
		// in lottery numbers.
		//for (int lotPos = 0; lotPos < numberOfPositions; lotPos++)
		//	lotteryNumber[lotPos] = generateRandomInRange(rangeLower, rangeUpper);
		generateLotteryNumber(
			lotteryNumber,
			numberOfPositions,
			rangeLower, rangeUpper,
			allowRepeats
		);

		//lotteryNumber[0] = generateRandomInRange(rangeLower, rangeUpper);
		//cout << "first lottery pos: " << lotteryNumber[0] << endl;
		//cout << "third lottery pos: " << lotteryNumber[2] << endl;

		// Display random value (digit or number)
		// for each position in lottery number.
		//for (int lotPos = 0; lotPos < numberOfPositions; lotPos++)
		//	cout << ' ' << lotteryNumber[lotPos];
		//cout << endl;
		displayLotteryNumber(lotteryNumber, numberOfPositions);
		
		//generateAndDisplayLotteryNumber(
		//	numberOfPositions,
		//	rangeLower, rangeUpper
		//);
	}

	return 0;
}

// FUNCTION DEFINITIONS.

// Read the type of lottery number from user, validates
// that it is entered correctly (requires user to re-enter
// if invalid), then returns the validated type.
LotteryType getLotteryType()
{
	// Letter entered by user for lottery type.
	char lotteryChoice;

	do
	{
		cout << "Enter type of lottery (d = daily numbers, m = million dollar): ";
		cin >> lotteryChoice;

		if (lotteryChoice == 'd' || lotteryChoice == 'D')
			return DAILY_NUMBERS;
		else if (lotteryChoice == 'm' || lotteryChoice == 'M')
			return MILLION_DOLLAR;
		else
			cerr << "Lottery type can be only 'd' or 'm'" << endl;
	} while (true);
}

// Allow user to enter number of values 'rangeVals'
// from which million-dollar lottery numbers are chosen.
// Postcondition: 'rangeVals' is validated to be at
// least as large as 'numPos', number of positions
// in lottery number.
void getRangeOfValues(int numPos, int& rangeVals)
{
	do {
		cout << "Enter range of values in lottery number "
			<< "(ex: N in 1...N, at least "
			<< numPos << "): ";
		cin >> rangeVals;
	} while (rangeVals < numPos);
}

// Generate a random number in a particular range.
// Precondition: 'lower' should be <= 'upper'.
// Postcondition: return value always between
// 'lower' and 'upper' (inclusively).
int generateRandomInRange(int lower, int upper)
{
	int rangeSize = upper - lower + 1;
	return rand() % rangeSize + lower;
}

//int computeTotalLotteryNumbers(int numPos)
//{
//	return static_cast<int>(pow(DIGITS_PER_POSITION, numPos));
//}

// Compute number of lottery numbers in which values
// are chosen from 'range' values, used to fill a
// number with 'numPos' positions. If 'replacement',
// then values can be re-used each position.
int computeTotalLotteryNumbers(int range,
	                           int numPos,
							   bool replacement)
{
	// Compute total lottery numbers for million-
	// dollar lottery. Initialize to number of choices
	// for 1st value.
	int numValsChosen = 1;
	int totalNums = range;

	// Compute total lottery numbers by considering
	// 2+ additional values in lottery number.
	while (numValsChosen < numPos)
	{
		// Compute increase in number of lottery
		// numbers due to additional value.
		if (replacement)
			totalNums *= range;
		else
			totalNums *= range - numValsChosen;

		// Record that chose an additional value.
		numValsChosen++;

		// Do not count duplicate lottery numbers
		// (same values but in different order).
		if (!replacement)
			totalNums /= numValsChosen;
	}

	return totalNums;
}

// Generate a random lottery number with 'numPos'
// positions. Each value may be a number in range
// from 'lower' to 'upper'.
//void generateAndDisplayLotteryNumber(int numPos, int lower, int upper)
//{
//	for (int posNum = 1; posNum <= numPos; posNum++)
//		cout << ' ' << generateRandomInRange(lower, upper);
//	cout << endl;
//}

// Returns whether the value 'newValue' already exists in array
// 'values' with 'numValues' filled in. Used to prevent duplicates
// in array.
// Precondition: 'values' cannot already contain a duplicate value.
bool containsDuplicate(const int values[], int numValues, int newValue)
{
	for (int pos = 0; pos < numValues; pos++)
		if (values[pos] == newValue)
			return true;
	return false;
}

// Generate a random lottery number with 'numPos' values.
// Each value may be a number in range from 'lower' to 'upper'.
// Will not repeat any values if 'allowDuplicates' is true.
void generateLotteryNumber(int lotNum[],
						   int numPos,
						   int lower, int upper,
						   bool allowDuplicates)
{
	for (int lotPos = 0; lotPos < numPos; lotPos++)
	{
		bool duplicate;
		do
		{
			lotNum[lotPos] = generateRandomInRange(lower, upper);
			duplicate = containsDuplicate(lotNum, lotPos, lotNum[lotPos]);
			if (duplicate)
				cout << "duplicate value: " << lotNum[lotPos] << endl;
		} while (!allowDuplicates && duplicate);
	}
}

// Display a lottery number with 'numPos' values
// separated by spaces.
void displayLotteryNumber(const int lotNum[], int numPos)
{
	// CANNOT CHANGE VALUE OF A CONST PARAMETER.
	//lotNum[0] = 0;
	for (int lotPos = 0; lotPos < numPos; lotPos++)
		cout << ' ' << lotNum[lotPos];
	cout << endl;
}
