/*
 * Name: Luis Marte
 * Project 1: Earthquake
 * Course: CSI107 (Spring 2024)
 * Date: Sat, April 13, 2024.
 * Description:  This program simulates the effects of
earthquakes on buildings made of different materials
(brick, wood, steel) and determines if the building
needs to be demolished based on the total damage.
 */

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <string>
#include <iomanip>
using namespace std;

// Data type definitions.

enum BuildingMaterial { BRICK, WOOD, STEEL };

//Declare constants 
const double MAX_MAGNITUDE = 10.0;
const double DEMOLISH_PERCENT = 50.0;

// Function prototypes.

// Generate random floating-point number between 'start'
// and 'end' (inclusive).
// Precondition: 'end' should be >= 'start'. Call srand()
// for different sequence of numbers.
// Postcondition: return value >= 'start' and <= 'end'.
double randomInRange(double start, double end);


//Fuction to generate a random number within a given range. 
double randomInRange(double min, double max)
{
    return min + static_cast<double>(rand()) / (static_cast<double>(RAND_MAX / (max - min)));
}


//Fuction to get the average percent damage based on building material and eathquake magnitude.
double getAveragePercentDamage(BuildingMaterial material, double magnitude)
{
    double averagePercentDamage = 0.0;

    if (magnitude < 6.0)
    {
        switch (material)
        {
        case BRICK:
            averagePercentDamage = 5.0;
            break;
        case WOOD:
            averagePercentDamage = 0.0;
            break;
        case STEEL:
            averagePercentDamage = 0.0;
            break;
        }
    }
    else if (magnitude >= 6.0 && magnitude < 7.0)
    {
        switch (material)
        {
        case BRICK:
            averagePercentDamage = 20.0;
            break;
        case WOOD:
            averagePercentDamage = 15.0;
            break;
        case STEEL:
            averagePercentDamage = 5.0;
            break;
        }
    }
    else if (magnitude >= 7.0 && magnitude < 8.0)
    {
        switch (material)
        {
        case BRICK:
            averagePercentDamage = 40.0;
            break;
        case WOOD:
            averagePercentDamage = 25.0;
            break;
        case STEEL:
            averagePercentDamage = 20.0;
            break;
        }
    }
    else if (magnitude >= 8.0 && magnitude < 9.0)
    {
        switch (material)
        {
        case BRICK:
            averagePercentDamage = 70.0;
            break;
        case WOOD:
            averagePercentDamage = 50.0;
            break;
        case STEEL:
            averagePercentDamage = 45.0;
            break;
        }
    }
    else if (magnitude >= 9.0)
    {
        switch (material)
        {
        case BRICK:
            averagePercentDamage = 100.0;
            break;
        case WOOD:
            averagePercentDamage = 100.0;
            break;
        case STEEL:
            averagePercentDamage = 100.0;
            break;
        }
    }

    return averagePercentDamage;
}






int main()
{
    srand(static_cast<unsigned int>(time(0)));
    //Variables
    BuildingMaterial material;
    double magnitude;
    int numTremors;
    double totalPercentDamage = 0.0;

    //Get Building material and using Char, for press the letter and got the material in the input.

    while (true)
    {
    const double DEMOLISH_DAMAGE_PERCENT = 50.0;

    // Uncomment to get different random sequence.
    //srand(static_cast<unsigned>(time(NULL)));


    char materialInput;
    cout << "\nEnter type of building material "
        << "(b=brick, w=wood, s=steel): ";
    cin >> materialInput;


    if (tolower(materialInput) == 'b')
    {
        material = BuildingMaterial::BRICK;
        break;
    }
    else if (tolower(materialInput) == 'w')
    {
        material = BuildingMaterial::WOOD;
        break;
    }
    else if (tolower(materialInput) == 's')
    {
        material = BuildingMaterial::STEEL;
        break;
    }
    else
    {
        cout << "Unknown building material: " << materialInput << endl;
        cout << endl;
    }
}





    // This code is part of a larger program that simulates the effect of earthquakes on a building.
      // I used setprecision setting the precision of the output to three decimal places.

    cout << setprecision(3);
    cout << "Enter earthquake magnitude on Richter scale (0-10, ex 7.4): ";
    cin >> magnitude;
    cout << endl;

    cout << "Enter number of tremors: ";
    cin >> numTremors;


    // Function definitions.
// 
// Generate random floating-point number between 'start'
// and 'end' (inclusive).
// Precondition: 'end' should be >= 'start'. Call srand()
// for different sequence of numbers.
// Postcondition: return value >= 'start' and <= 'end'.


    // For loop is using to display the average percent damage of the building multiple times.
    for (int i = 0; i < numTremors; i++)
    {
        double averagePercentDamage = getAveragePercentDamage(material, magnitude);

        double minPercentDamage = averagePercentDamage * 0.8;

        double maxPercentDamage = min(averagePercentDamage * 1.2, 100.0);

        double actualPercentDamage = randomInRange(minPercentDamage, maxPercentDamage);
        totalPercentDamage += actualPercentDamage;

        cout << "Building damage from tremor # " << i + 1 << ": " << actualPercentDamage << "%" << endl;

        if (totalPercentDamage >= 100.0)
        {
            break;
        }
   
    }
    cout << endl;

    /////
    cout << "Total building damage: " << totalPercentDamage << "%" << endl;

    

    /////
    if (totalPercentDamage >= DEMOLISH_PERCENT)
    {
        cout << "The building must be demolished." << endl;
    }

    return 0;
}







