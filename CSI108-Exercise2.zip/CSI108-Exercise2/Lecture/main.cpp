/*
 * Name: YOUR NAME
 * Exercise 2: Default Measurement
 * Course: CSI108 (Fall 2024)
 * Date:  September 24, 2024
 * Description: Class with objects as member data; using "const" correctly
 *				with reference parameters and member functions.
 */

#include <iostream>
#include <string>
using namespace std;

enum MeasureUnits { UNITS_CUPS, UNITS_FLUID_OUNCES };

// IngredMeasure class definition with member data and
// prototypes for member functions.
class IngredMeasure
{
public:
	static const double OUNCES_IN_CUP;

	// Constructors
	IngredMeasure(double initAmt, MeasureUnits initUnits);
	IngredMeasure(MeasureUnits initUnits);
	IngredMeasure();

	// Accessors & mutators
	double getAmt() const;
	MeasureUnits getUnits() const;
	void output() const;
	void convertToUnits(MeasureUnits newUnits);
	void set(double newAmt, MeasureUnits newUnits);
	// Precondition: newAmt must be non-negative.

	void set(MeasureUnits newUnits);
	// Postcondition: sets measurement to have zero amount with
	// the specified units.

private:
	double amt;
	MeasureUnits units;

	// Helper function to validate range of amount.
	static void checkAmt(double newAmt);
};

// Ingredient class definition.
class Ingredient
{
public:
	// Constructors
	Ingredient(double initAmt, MeasureUnits initUnits, const string& initName);
	Ingredient(const IngredMeasure& measure, const string& initName);
	Ingredient();

	// Accessors & mutators
	string getName() const;
	void output() const;
	void setName(const string& newName);

private:
	IngredMeasure measurement;
	string name;
};

int main()
{
	IngredMeasure measure2(7.0, UNITS_FLUID_OUNCES);

	Ingredient ingred1(1.5, UNITS_CUPS, "flour");
	Ingredient ingred2(measure2, "soy milk");

	// Output floating-point numbers to one decimal place.
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(1);

	cout << "ingredient1: ";
	ingred1.output();
	cout << endl;

	cout << "ingredient2: ";
	ingred2.output();
	cout << endl;

	return 0;
}

// IngredMeasure static member definitions.

const double IngredMeasure::OUNCES_IN_CUP = 8.0;

// IngredMeasure member function definitions.

IngredMeasure::IngredMeasure(double initAmt, MeasureUnits initUnits)
	: amt(initAmt), units(initUnits)
{
	checkAmt(amt);
}

IngredMeasure::IngredMeasure(MeasureUnits initUnits)
	: amt(0.0), units(initUnits)
{
}

IngredMeasure::IngredMeasure()
	: IngredMeasure(0.0, UNITS_CUPS)
{
}

double IngredMeasure::getAmt() const
{
	return amt;
}

MeasureUnits IngredMeasure::getUnits() const
{
	return units;
}

void IngredMeasure::output() const
{
	cout << amt << ' ';

	if (units == UNITS_CUPS)
		cout << "cups";
	else if (units == UNITS_FLUID_OUNCES)
		cout << "ounces";
}

void IngredMeasure::convertToUnits(MeasureUnits newUnits)
{
	if (units == UNITS_FLUID_OUNCES && newUnits == UNITS_CUPS)
		amt /= OUNCES_IN_CUP;
	else if (units == UNITS_CUPS && newUnits == UNITS_FLUID_OUNCES)
		amt *= OUNCES_IN_CUP;

	units = newUnits;
}

void IngredMeasure::set(double newAmt, MeasureUnits newUnits)
{
	checkAmt(newAmt);

	amt = newAmt;
	units = newUnits;
}

void IngredMeasure::set(MeasureUnits newUnits)
{
	set(0.0, newUnits);
}

void IngredMeasure::checkAmt(double newAmt)
{
	if (newAmt < 0.0)
		cerr << "Invalid negative measure amount: " << newAmt << endl;
}

// Ingredient member function definitions.

Ingredient::Ingredient(double initAmt, MeasureUnits initUnits, const string& initName)
	: measurement(initAmt, initUnits), name(initName)
{
}

Ingredient::Ingredient(const IngredMeasure& measure, const string& initName)
	: measurement(measure.getAmt(), measure.getUnits()), name(initName)
{
}

Ingredient::Ingredient()
	: measurement(), name()
{
}

string Ingredient::getName() const
{
	return name;
}

void Ingredient::output() const
{
	measurement.output();
	cout << '\t' << name;
}

void Ingredient::setName(const string& newName)
{
	name = newName;
}
