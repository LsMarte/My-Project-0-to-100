/*
 * Name: YOUR NAME
 * Measures Project
 * Course: CSI108 (Fall 2024)
 * Date: October 21, 2024
 * Description: Using dynamic allocation in class with destructor,
 *				copy constructor, and assignment operator.
 */

#include <iostream>
#include <string>
using namespace std;

enum MeasureUnits { UNITS_CUPS, UNITS_FLUID_OUNCES };

// IngredMeasure class definition.
class IngredMeasure
{
public:
	static const double OUNCES_IN_CUP;

	IngredMeasure();
	IngredMeasure(double initAmt, MeasureUnits initUnits);

	double getAmt() const;
	MeasureUnits getUnits() const;
	void output() const;
	void convertToUnits(MeasureUnits newUnits);
	// Precondition: newUnits must be one of valid constants.
	void set(double newAmt, MeasureUnits newUnits);
	// Precondition: newUnits must be one of valid constants.
	void input();

private:
	double amtCups;
	MeasureUnits units;
};

// Ingredient class definition.
class Ingredient
{
public:
	Ingredient();
	Ingredient(const IngredMeasure& initMeasure,
			   const string& initName);

	// ADD INLINE DESTRUCTOR, JUST TO SEE CALLED WHEN
	// DELETE ARRAY OF Ingredient OBJECTS.


	void output() const;
	void setName(const string& newName);
	void input();

private:
	IngredMeasure measurement;
	string name;
};

// Recipe class definition.
class Recipe
{
public:
	Recipe();

	// USER-DEFINED COPY CONSTRUCTOR TAKES REFERENCE
	// TO OBJECT OF SAME TYPE AS CLASS.
	//Recipe(const Recipe& otherRecipe);
	
	// ADD DESTRUCTOR

	// USER-DEFINED ASSIGNMENT OPERATOR
	//void operator =(const Recipe& otherRecipe);

	void output() const;
	void input(int numInputIngreds);

private:
	Ingredient* ingreds;  // pointer for dynamically-allocated array
	int numIngreds;       // array size
};

// Prototypes for function dealing with recipes.

// COPY CONSTRUCTOR INVOKED WHEN OBJECT
// PASSED "BY VALUE".
void outputRecipe(Recipe someRecipe);

// COPY CONSTRUCTOR INVOKED WHEN RETURN OBJECT.
Recipe getRecipe();

int main()
{
	Recipe recipe1;

	// Output floating-point numbers to one decimal place.
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(1);

	int numIngreds;
	cout << "Number of ingredients? ";
	cin >> numIngreds;
	cin.ignore();  // swallow newline after number

	cout << "\nEnter ingredients (one per line):" << endl;
	recipe1.input(numIngreds);

	//cout << "\nCall function that returns object" << endl;
	//recipe1 = getRecipe();

	// TEST COPYING AND ASSIGNING FOR OBJECTS WITH DYNAMICALLY-
	// ALLOCATED DATA.  (FOR COMPARISON, TRY THE FOLLOWING WITHOUT
	// A USER-DEFINED COPY CONSTRUCTOR AND ASSIGNMENT OPERATOR.)

	{  // Inner block
		cout << "\nBeginning of block" << endl;

		cout << "\nInitializing recipe" << endl;
		// ADD CODE TO TEST COPY CONSTRUCTOR
		Recipe recipe2;

		cout << "\nAssigning recipes" << endl;
		// TEST ASSIGNMENT (LATER CHAINING OF
		// ASSIGNMENT AND SELF-ASSIGNMENT).

		cout << "\nrecipe2 ingredients:" << endl;
		recipe2.output();

		//cout << "\nPass recipe by value" << endl;
		//outputRecipe(recipe2);

		cout << "\nRight before end of block" << endl;
	} // Recipes declared in block GO OUT-OF-SCOPE HERE
	  // DESTRUCTORS CALLED FOR BLOCK-SCOPE OBJECTS

	cout << "\nrecipe1 ingredients:" << endl;
	recipe1.output();

	cout << "\nRight before end of main()" << endl;

	return 0;
}

// Definition for function dealing with recipes.

// COPY CONSTRUCTOR INVOKED WHEN OBJECT
// PASSED "BY VALUE".  Normally, would
// use constant reference here (just for
// demonstration purposes).
// DESTRUCTOR CALLED WHEN PARAMETER (COPY)
// GOES OUT OF SCOPE.
void outputRecipe(Recipe someRecipe)
{
	someRecipe.output();
}

// COPY CONSTRUCTOR INVOKED WHEN RETURN OBJECT.
// DESTRUCTOR CALLED WHEN LOCAL OBJECT GOES OUT
// OF SCOPE.
Recipe getRecipe()
{
	Recipe inRecipe;
	int numIngreds;

	cout << "Number of ingredients? ";
	cin >> numIngreds;
	cin.ignore();  // swallow newline after number

	cout << "\nEnter ingredients (one per line):" << endl;
	inRecipe.input(numIngreds);

	return inRecipe;
}

// IngredMeasure static member definitions.

const double IngredMeasure::OUNCES_IN_CUP = 8.0;

// IngredMeasure member function definitions.

IngredMeasure::IngredMeasure()
	: amtCups(0.0), units(UNITS_CUPS)
{
}

IngredMeasure::IngredMeasure(double initAmt, MeasureUnits initUnits)
{
	set(initAmt, initUnits);
}

double IngredMeasure::getAmt() const
{
	if (units == UNITS_FLUID_OUNCES)
		return amtCups * OUNCES_IN_CUP;
	return amtCups;
}

MeasureUnits IngredMeasure::getUnits() const
{
	return (*this).units;  // practice with "this"
}

void IngredMeasure::output() const
{
	// Use getAmt() to output the amount in the proper stored units.
	cout << this->getAmt() << ' ';

	if (units == UNITS_CUPS)
		cout << "cups";
	else if (units == UNITS_FLUID_OUNCES)
		cout << "ounces";
}

void IngredMeasure::convertToUnits(MeasureUnits newUnits)
{
	// No amount conversion necessary since always stored as cups.
	units = newUnits;
}

void IngredMeasure::set(double newAmt, MeasureUnits newUnits)
{
	units = newUnits;

	if (units == UNITS_FLUID_OUNCES)
		amtCups = newAmt / OUNCES_IN_CUP;
	else
		amtCups = newAmt;
}

void IngredMeasure::input()
{
	double newAmt;
	string unitsName;

	cin >> newAmt >> unitsName;

	if (unitsName == "cups")
		set(newAmt, UNITS_CUPS);
	else if (unitsName == "ounces")
		set(newAmt, UNITS_FLUID_OUNCES);
	else
	{
		cerr << "Unknown measure units \"" << unitsName << "\"" << endl;

		// Just store amount with units of cups.
		amtCups = newAmt;
		units = UNITS_CUPS;
	}
}

// Ingredient member function definitions.

Ingredient::Ingredient()
	: measurement(), name("")
{
	// SEE CALLED WHEN ALLOCATE ARRAY OF Ingredient OBJECTS.
	//cout << "In Ingredient DEFAULT C-TOR" << endl;
}

Ingredient::Ingredient(
			const IngredMeasure& initMeasure,
			const string& initName)
	// INSTEAD INVOKE COPY CONSTRUCTOR TO INITIALIZE MEASURE OBJECT
	: measurement(initMeasure.getAmt(), initMeasure.getUnits()),
	  name(initName)
{
}

void Ingredient::output() const
{
	measurement.output();
	cout << '\t' << name;
}

void Ingredient::setName(const string& newName)
{
	name = newName;
}

void Ingredient::input()
{
	measurement.input();
	cin >> ws;  // skip whitespace
	getline(cin, name);
}

// Recipe member function definitions.

Recipe::Recipe()
	: ingreds(NULL), numIngreds(0)
{
}

// USER-DEFINED COPY CONSTRUCTOR
//Recipe::Recipe(const Recipe& otherRecipe)
//{
//	cout << "In Recipe COPY CONSTRUCTOR" << endl;
//	
//	// ALLOCATE NEW SPACE.
//	ingreds = new Ingredient[otherRecipe.numIngreds];
//	
//	// COPY OTHER MEMBERS.
//	numIngreds = otherRecipe.numIngreds;
//
//	// COPY INGREDIENTS FROM OTHER RECIPE.
//	for (int i = 0; i < numIngreds; i++)
//		ingreds[i] = otherRecipe.ingreds[i];
//}

// ADD DESTRUCTOR


// ASSIGNMENT OPERATOR
//void Recipe::operator =(const Recipe& otherRecipe)
//{
//
//}

void Recipe::output() const
{
	for (int i = 0; i < numIngreds; i++)
	{
		ingreds[i].output();
		cout << endl;
	}
}

void Recipe::input(int numInputIngreds)
{
	// DEALLOCATE ANY EXISTING ARRAY FIRST.
	delete[] ingreds;

	// Allocate new array.
	ingreds = new Ingredient[numInputIngreds];

	// Keep track of dynamically-allocated array size.
	numIngreds = numInputIngreds;

	// Read in all ingredients.
	for (int i = 0; i < numIngreds; i++)
		ingreds[i].input();
}
