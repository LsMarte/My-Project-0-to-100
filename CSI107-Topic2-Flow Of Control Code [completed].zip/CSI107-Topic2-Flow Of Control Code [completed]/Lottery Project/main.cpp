/*
 * Name: Your Name
 * Lottery Project
 * Course: CSI107 (Spring 2024)
 * Date: January 30, 2024
 * Description: Compute the odds of any single
 *				daily number or million-dollar
 *				lottery number coming up.
 */

#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <ctime>
using namespace std;

// Enumeration for type of lottery.
enum LotteryType { DAILY_NUMBERS, MILLION_DOLLAR };

int main()
{
	const int MAX_POSITIONS = 8;
	const int DIGITS_PER_POSITION = 10;
	const double ODDS_TO_GENERATE = 1e-7;

	char lotteryChoice;
	LotteryType lotteryType;

	int numberOfPositions;

	// Range of values for million-dollar lottery.
	int rangeOfValues;

	int totalLotteryNumbers;
	double probabilityLotteryNumber;
	double oddsLotteryNumber;

	// Set to display floating-pts values using
	// scientific notation with N decimal places.
	cout << scientific << setprecision(8);

	// Get type of lottery game.
	//bool validType;
	do
	{
		cout << "Enter type of lottery (d = daily numbers, m = million dollar): ";
		cin >> lotteryChoice;

		if (lotteryChoice == 'd' || lotteryChoice == 'D')
		{
			lotteryType = DAILY_NUMBERS;
			//validType = true;
			//break;
		}
		else if (lotteryChoice == 'm' || lotteryChoice == 'M')
		{
			lotteryType = MILLION_DOLLAR;
			//validType = true;
			//break;
		}
		else
		{
			cerr << "Lottery type can be only 'd' or 'm'" << endl;
			//validType = false;
			continue;  // DON'T DO IT!
		}
		break;  // NOT A GREAT DESIGN!
	} while (true);
	// FILL IN A CONDITION FOR LOOP ABOVE
	// AND USE break WITHIN LOOP.
	//} while (!validType);
	//} while (lotteryChoice != 'd' && lotteryChoice != 'D' &&
	//			lotteryChoice != 'm' && lotteryChoice != 'M');

	// Get number of positions.
	do
	{
		cout << "Enter number of positions in lottery number (between 1 and "
			 << MAX_POSITIONS << "): ";
		cin >> numberOfPositions;
	} while (numberOfPositions < 1 || numberOfPositions > MAX_POSITIONS);

	// Compute total lottery numbers differently
	// based on type of lottery.

	if (lotteryType == DAILY_NUMBERS)
	{  // daily numbers
		cout << "daily numbers" << endl;
		// Compute total lottery numbers.
		totalLotteryNumbers = static_cast<int>(pow(DIGITS_PER_POSITION, numberOfPositions));

	}
	else
	{  // million dollar
		cout << "million dollar" << endl;

		// WILL FILL IN WHAT NEEDED FOR MILLION DOLLAR LOTTERY.
	
		do {
			cout << "Enter range of values in lottery number "
				<< "(ex: N in 1...N, at least "
				<< numberOfPositions << "): ";
			cin >> rangeOfValues;
		} while (rangeOfValues < numberOfPositions);

		// Compute total lottery numbers (1st value).
		int numberOfValuesChosen = 1;
		totalLotteryNumbers = rangeOfValues;

		// Compute total lottery numbers (2nd value).
		//totalLotteryNumbers =
		//	totalLotteryNumbers *
		//		(rangeOfValues - numberOfValuesChosen);
		//numberOfValuesChosen =
		//	numberOfValuesChosen + 1;
		//totalLotteryNumbers =
		//	totalLotteryNumbers / numberOfValuesChosen;

		// Compute total lottery numbers (2nd or more value).
		// SAME AS 2nd CHOOSING VALUE, BUT REWRITTEN.
		while (numberOfValuesChosen < numberOfPositions)
		{
			totalLotteryNumbers *=
				rangeOfValues - numberOfValuesChosen;
			numberOfValuesChosen++;
			// DEMO PREFIX INCR BELOW (DON'T USE, WRITE
			// AS SEPARATE STATEMENT LIKE ABOVE).
			//totalLotteryNumbers /= ++numberOfValuesChosen;
			totalLotteryNumbers /= numberOfValuesChosen;
		}
	}

	// Compute probability of single lottery number.
	// Probability is number of occurrences of event
	// of interest out of total number of possible events
	// (if all events are equiprobable).
	probabilityLotteryNumber = 1.0 / totalLotteryNumbers;

	// Display probability of single lottery number.
	//cout << "Probability of lottery number: "
	//	 << probabilityLotteryNumber << endl;

	// Compute odds of a single lottery number (favorable
	// event) out of all other lottery numbers (unfavorable
	// events) [here, written in terms of probability].
	// See: https://towardsdatascience.com/odds-probability-c9cf80405027
	oddsLotteryNumber =
		probabilityLotteryNumber / (1.0 - probabilityLotteryNumber);

	// Display odds of single lottery number.
	cout << "Odds of lottery number: "
		 << oddsLotteryNumber << endl;

	if (oddsLotteryNumber >= ODDS_TO_GENERATE)
	{
		srand(static_cast<unsigned int>(time(NULL)));

		cout << "Lottery number:";

		for (int posNum = 1; posNum <= numberOfPositions; posNum++)
		{
			cout << ' ';
			//cout << (lotteryType == DAILY_NUMBERS
			//	? rand() % DIGITS_PER_POSITION
			//	: rand() % rangeOfValues + 1);

			switch (lotteryType)
			{
			case DAILY_NUMBERS:
				// Generate daily number.
				cout << rand() % DIGITS_PER_POSITION;
				break;

			case MILLION_DOLLAR:
				// Million dollar number.
				cout << rand() % rangeOfValues + 1;
				break;
			}
		}
		cout << endl;
	}

	return 0;
}