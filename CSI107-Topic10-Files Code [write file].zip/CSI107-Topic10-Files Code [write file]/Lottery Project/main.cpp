/*
 * Name: Your Name
 * Lottery Project
 * Course: CSI107 (Spring 2024)
 * Date: May 7, 2024
 * Description: Compute the odds of any single
 *				daily number or million-dollar
 *				lottery number coming up. If
 *				odds of winning with 1 number
 *				are above a threshold, generate
 *				a random lottery number that is
 *				output to a file. Store lottery
 *				number in array so that duplicates
 *				values can be avoided for million-
 *				dollar lotteries.
 */

#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cassert>
#include <limits>
#include <cctype>
#include <string>
#include <fstream>
using namespace std;

// Class for range of numbers.
class Range
{
public:
	Range(int initLower, int initUpper);
	Range(int initLowerUpper);
	Range();  // default constructor

	int size() const;
	int getLower() const { return lower; }  // inline function
	int getUpper() const;
	void set(int newLower, int newUpper);

private:
	int lower;
	int upper;

	void checkRange(int newLower, int newUpper);
};

// FUNCTION PROTOTYPES.

// Overload left bit shift for Range.
Range operator <<(const Range& range, int amt);

// Read the type of lottery number from user, validates
// that it is entered correctly (requires user to re-enter
// if invalid), then returns the number of positions,
// range of each value, and whether duplicate values
// are allowed for that lottery.
void getLotteryType(
	int& numPos,
	Range& range,
	bool& allowDuplicates);

// Allow user to enter number of values returned as 'upper'
// part of Range from which million-dollar lottery numbers
// are chosen ('lower' part of Range is always 1).
Range getRangeOfValues(int numPos);
// Postcondition: 'upper' part of Range is validated to be
// at least as large as 'numPos', number of positions in
// lottery number.

// Generate a random number in a particular range.
int generateRandomInRange(const Range& range);
// Precondition: 'lower' member should be <= 'upper' member
// of Range structure.
// Postcondition: return value always between
// 'lower' and 'upper' (inclusively).

// Compute number of lottery numbers in which values
// are chosen from 'range' values, used to fill a
// number with 'numPos' positions. If 'replacement',
// then values can be re-used each position.
int computeTotalLotteryNumbers(int range,
	                           int numPos,
	                           bool replacement = false);

// Returns whether the value 'newValue' already exists in array
// 'values' with 'numValues' filled in. Used to prevent duplicates
// in array.
bool containsDuplicate(const int values[], int numValues, int newValue);
// Precondition: 'values' cannot already contain a duplicate value.

// Generate a random lottery number with 'numPos' values.
// Each value may be a number in range from 'lower' to 'upper'.
// Will not repeat any values if 'allowDuplicates' is true.
void generateLotteryNumber(int lotNum[],
						  int numPos,
					      const Range& range,
						  bool allowDuplicates);

// Write a lottery number with 'numPos' values
// separated by spaces to file.
void displayLotteryNumber(const int lotNum[], int numPos);

// Convert C-string to lowercase.
void convertToLowercase(string& text);

int main()
{
	// Maximum values (digits or number) in a
	// lottery number.
	const int MAX_POSITIONS = 8;

	// Minimum odds of winning in order to
	// generate a random lottery number.
	const double ODDS_TO_GENERATE = 1e-7;

	// Total number of possible lottery numbers
	// for chosen type of lottery.
	int totalLotteryNumbers;

	// Probability of winning via a single lottery
	// number for chosen type of lottery.
	double probabilityLotteryNumber;

	// Odds of winning via a single lottery
	// number for chosen type of lottery.
	double oddsLotteryNumber;

	// Display floating-pts values using
	// scientific notation with setprecision()
	// decimal places.
	cout << scientific << setprecision(8);

	// Number of values (digits or numbers) in
	// lottery number.
	int numberOfPositions;

	// Range of values (i.e., lower and highest
	// value) each position in lottery number.
	Range range;
	
	// Whether values may be repeated in lottery number.
	bool allowRepeats;

	// Get the number of values, range of each value, and
	// whether value may be repeated in lottery number
	// based on the user's requested lottery.
	getLotteryType(numberOfPositions, range, allowRepeats);

	// Compute total lottery numbers for a type of lottery
	// given range of values and whether can repeat values.
	totalLotteryNumbers =
		computeTotalLotteryNumbers(
			range.size(),
			numberOfPositions,
			allowRepeats
		);

	// Compute probability of single lottery number.
	// Probability is number of occurrences of event
	// of interest out of total number of possible events
	// (if all events are equiprobable).
	probabilityLotteryNumber = 1.0 / totalLotteryNumbers;

	// Compute odds of a single lottery number (favorable
	// event) out of all other lottery numbers (unfavorable
	// events) [here, written in terms of probability].
	// See: https://towardsdatascience.com/odds-probability-c9cf80405027
	oddsLotteryNumber =
		probabilityLotteryNumber / (1.0 - probabilityLotteryNumber);

	// Ensure odds are not negative.
	assert(oddsLotteryNumber >= 0.0);

	// Display odds of single lottery number for
	// chosen type of lottery.
	cout << "Odds of lottery number: "
		 << oddsLotteryNumber << endl;

	// Test whether odds are sufficient to warrant
	// generating a lottery number.
	if (oddsLotteryNumber >= ODDS_TO_GENERATE)
	{
		// Seed random numbers to get a different
		// sequence each "time" run.
		srand(static_cast<unsigned int>(time(NULL)));

		// Display random lottery number.

		int lotteryNumber[MAX_POSITIONS];

		cout << "Lottery number:";

		// Generate random values for position in lottery numbers.
		generateLotteryNumber(
			lotteryNumber,
			numberOfPositions,
			range,
			allowRepeats
		);

		// Display random value (digit or number) for each
		// position in lottery number.
		displayLotteryNumber(lotteryNumber, numberOfPositions);
	}

	return 0;
}

// FUNCTION DEFINITIONS.

// Range member function definitions.

Range::Range(int initLower, int initUpper)
	: lower(initLower), upper(initUpper)  // initialization section
{
	checkRange(lower, upper);
}

Range::Range(int initLowerUpper)
{
	lower = upper = initLowerUpper;
}

Range::Range()
	: Range(0)  // constructor delegation
{
}

int Range::size() const
{
	return upper - lower + 1;
}

int Range::getUpper() const
{
	return upper;
}

void Range::set(int newLower, int newUpper)
{
	lower = newLower;
	upper = newUpper;

	checkRange(lower, upper);
}

void Range::checkRange(int newLower, int newUpper)
{
	if (newLower > newUpper)
		cerr << "Range lower (" << newLower << ") should not be "
		     << "greater than upper (" << newUpper << ")" << endl;
}

// Overload left bit shift for Range.
Range operator <<(const Range& range, int amt)
{
	return Range(range.getLower() - amt, range.getUpper() - amt);
}

// Read the type of lottery number from user, validates
// that it is entered correctly (requires user to re-enter
// if invalid), then returns the number of positions,
// range of each value, and whether duplicate values
// are allowed for that lottery.
void getLotteryType(
	int& numPos,
	Range& range,
	bool& allowDuplicates)
{
	const string EX_LOTTERY_NAME = "the daily numbers";

	string lotteryName;
    
	do
	{
		cout << "Enter name of lottery (ex: "
 			 << EX_LOTTERY_NAME << "): ";
		getline(cin, lotteryName);
		
		string confirmPrompt;
		confirmPrompt = "Selected: ";
		confirmPrompt = confirmPrompt + lotteryName;
		confirmPrompt += ". Confirm (y/n)? ";
		cout << confirmPrompt;
		char confirmAns;
		cin >> confirmAns;
		// EAT REST OF LINE.
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
		
		confirmAns = tolower(confirmAns);

		if (confirmAns != 'y')
		    continue;

		// Convert lottery name to lowercase to allow
		// case-insensitive testing.
		convertToLowercase(lotteryName);

		if (lotteryName == "the daily numbers")
		{
			numPos = 4;
			//range.set(0, 9);  // using mutator
			// Use overloaded operator.
			range = Range(1, 10) << 1;
			allowDuplicates = true;
			break;
			//return;
		}
		else if (lotteryName == "megabucks")
		{
			numPos = 6;
			range = Range(1, 44);  // assigns anonymous object
			allowDuplicates = false;
			break;
		}
		else if (lotteryName == "mass cash")
		{
			numPos = 5;
			range = Range(1, 35);
			allowDuplicates = false;
			break;
		}
		else
			cerr << "Unknown lottery name: " << lotteryName << endl;
	} while (true);
}

// Allow user to enter number of values returned as 'upper'
// part of Range from which million-dollar lottery numbers
// are chosen ('lower' part of Range is always 1).
// Postcondition: 'upper' part of Range is validated to be
// at least as large as 'numPos', number of positions in
// lottery number.
Range getRangeOfValues(int numPos)
{
	int rangeUpper;

	do {
		cout << "Enter range of values in lottery number "
			<< "(ex: N in 1...N, at least "
			<< numPos << "): ";
		cin >> rangeUpper;
	} while (rangeUpper < numPos);

	return Range(1, rangeUpper); // anonymous object
}

// Generate a random number in a particular range.
// Precondition: 'lower' member should be <= 'upper' member
// of Range structure.
// Postcondition: return value always between
// 'lower' and 'upper' (inclusively).
int generateRandomInRange(const Range& range)
{
	return rand() % range.size() + range.getLower();
}

// Compute number of lottery numbers in which values
// are chosen from 'range' values, used to fill a
// number with 'numPos' positions. If 'replacement',
// then values can be re-used each position.
int computeTotalLotteryNumbers(int range,
	                           int numPos,
							   bool replacement)
{
	// Compute total lottery numbers for million-
	// dollar lottery. Initialize to number of choices
	// for 1st value.
	int numValsChosen = 1;
	int totalNums = range;

	// Compute total lottery numbers by considering
	// 2+ additional values in lottery number.
	while (numValsChosen < numPos)
	{
		// Compute increase in number of lottery
		// numbers due to additional value.
		if (replacement)
			totalNums *= range;
		else
			totalNums *= range - numValsChosen;

		// Record that chose an additional value.
		numValsChosen++;

		// Do not count duplicate lottery numbers
		// (same values but in different order).
		if (!replacement)
			totalNums /= numValsChosen;
	}

	return totalNums;
}

// Returns whether the value 'newValue' already exists in array
// 'values' with 'numValues' filled in. Used to prevent duplicates
// in array.
// Precondition: 'values' cannot already contain a duplicate value.
bool containsDuplicate(const int values[], int numValues, int newValue)
{
	for (int pos = 0; pos < numValues; pos++)
		if (values[pos] == newValue)
			return true;
	return false;
}

// Generate a random lottery number with 'numPos' values.
// Each value may be a number in range from 'lower' to 'upper'.
// Will not repeat any values if 'allowDuplicates' is true.
void generateLotteryNumber(int lotNum[],
						   int numPos,
						   const Range& range,
						   bool allowDuplicates)
{
	for (int lotPos = 0; lotPos < numPos; lotPos++)
	{
		// Generate a random value (if duplicates are
		// not allowed, choose another random value
		// until not a duplicate).
		bool duplicate;
		do
		{
			lotNum[lotPos] = generateRandomInRange(range);
			duplicate = containsDuplicate(lotNum, lotPos, lotNum[lotPos]);
		} while (!allowDuplicates && duplicate);
	}
}

// Write a lottery number with 'numPos' values
// separated by spaces to file.
void displayLotteryNumber(const int lotNum[], int numPos)
{
	const string lotteryNumFilename = "lotterynum.txt";
	
	ofstream lotteryFile;
	lotteryFile.open(lotteryNumFilename);
	
	for (int lotPos = 0; lotPos < numPos; lotPos++)
		lotteryFile << ' ' << lotNum[lotPos];
	lotteryFile << endl;

	// Ensure buffered data written to file.
	lotteryFile.close();
	
	cout << " stored in file: " << lotteryNumFilename << endl;
}

// Convert C-string to lowercase.
void convertToLowercase(string& text)
{
	for (int letNum = 0; letNum < text.length(); letNum++)
		text[letNum] = tolower(text[letNum]);
}
