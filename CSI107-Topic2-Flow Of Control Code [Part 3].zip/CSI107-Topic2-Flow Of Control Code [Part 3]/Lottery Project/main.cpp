/*
 * Name: Your Name
 * Lottery Project
 * Course: CSI107 (Spring 2024)
 * Date: January 30, 2024
 * Description: Compute the odds of any single
 *				daily number or million-dollar
 *				lottery number coming up.
 */

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main()
{
	const int DIGITS_PER_POSITION = 10;

	char lotteryType;
	int numberOfPositions;
	int totalLotteryNumbers;
	double probabilityLotteryNumber;
	double oddsLotteryNumber;

	// Set to display floating-pts values using
	// scientific notation with N decimal places.
	cout << scientific << setprecision(8);

	// Get type of lottery game.
	cout << "Enter type of lottery (d = daily numbers, m = million dollar): ";
	cin >> lotteryType;

	// Get number of positions.
	cout << "Enter number of positions in lottery number: ";
	cin >> numberOfPositions;

	// Compute total lottery numbers differently
	// based on type of lottery.

	if (lotteryType == 'd' || lotteryType == 'D')
	{  // daily numbers
		cout << "daily numbers" << endl;
		// Compute total lottery numbers.
		totalLotteryNumbers = static_cast<int>(pow(DIGITS_PER_POSITION, numberOfPositions));

	}
	else
	{  // million dollar
		cout << "million dollar" << endl;

		// WILL FILL IN WHAT NEEDED FOR MILLION DOLLAR LOTTERY.
	
		// Get range of values.
		int rangeOfValues;
		cout << "Enter range of values in lottery number "
		     << "(ex: N in 1...N): ";
		cin >> rangeOfValues;

		// Compute total lottery numbers (1st value).
		int numberOfValuesChosen = 1;
		totalLotteryNumbers = rangeOfValues;

		// Compute total lottery numbers (2nd value).
		totalLotteryNumbers =
			totalLotteryNumbers *
				(rangeOfValues - numberOfValuesChosen);
		numberOfValuesChosen =
			numberOfValuesChosen + 1;
		totalLotteryNumbers =
			totalLotteryNumbers / numberOfValuesChosen;

		// Compute total lottery numbers (3rd value).
		// SAME AS 2nd CHOOSING VALUE, BUT REWRITTEN.
		totalLotteryNumbers *=
				rangeOfValues - numberOfValuesChosen;
		//numberOfValuesChosen++;
		// DEMO PREFIX INCR BELOW (DON'T USE, WRITE
		// AS SEPARATE STATEMENT LIKE ABOVE).
		totalLotteryNumbers /= ++numberOfValuesChosen;
	}

	// Compute probability of single lottery number.
	// Probability is number of occurrences of event
	// of interest out of total number of possible events
	// (if all events are equiprobable).
	probabilityLotteryNumber = 1.0 / totalLotteryNumbers;

	// Display probability of single lottery number.
	//cout << "Probability of lottery number: "
	//	 << probabilityLotteryNumber << endl;

	// Compute odds of a single lottery number (favorable
	// event) out of all other lottery numbers (unfavorable
	// events) [here, written in terms of probability].
	// See: https://towardsdatascience.com/odds-probability-c9cf80405027
	oddsLotteryNumber =
		probabilityLotteryNumber / (1.0 - probabilityLotteryNumber);

	// Display odds of single lottery number.
	cout << "Odds of lottery number: "
		 << oddsLotteryNumber << endl;

	return 0;
}