/*
 * Name: YOUR NAME
 * Exercise 1b: Snow Day (C++ Program)
 * Course: CSI107 (Spring 2024)
 * Date: THE DATE
 * Description: ??
 */

#include <iostream>
using namespace std;

int main()
{

	return 0;
}